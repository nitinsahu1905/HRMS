import Punchbox from "./@punchbox/page";

export default function Layout({ children, punchbox }) {
  return (
    <div className="bg-sky-color w-full h-[100vh] p-5 flex flex-col gap-5">
        <div>{children}</div>
        <div> {punchbox}</div>
    </div>
  );
}

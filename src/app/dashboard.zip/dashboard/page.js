import React from 'react'

const dashboard = () => {
  return (
    <div>
        <h1 className='text-dark-blue text-[24px] font-bold'>Welcome Admin!</h1>
        <p className='text-primary-blue'>Dashboard</p>
    </div>
  )
}

export default dashboard